package com.db.awmd.challenge.transaction;

public interface TransactionCallback {
	
	public void process();
}
